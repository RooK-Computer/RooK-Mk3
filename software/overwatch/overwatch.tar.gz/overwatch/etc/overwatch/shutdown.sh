#!/bin/bash

/usr/sbin/halt
